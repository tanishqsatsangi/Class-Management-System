package com.minor.classmanagementsystem.Studentactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.minor.classmanagementsystem.R;
import com.minor.classmanagementsystem.mainactivites.MainActivity;

public class StudentDeleteActivity extends AppCompatActivity {
EditText id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_delete);
    id=findViewById(R.id.student_delete_studentid_et);
        final StudentDBHelper sdb=new StudentDBHelper(StudentDeleteActivity.this);
        findViewById(R.id.student_delete_submit_btn).setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Integer deletedRows = sdb.deletedata(id.getText().toString());
            if(deletedRows > 0)
                Toast.makeText(StudentDeleteActivity.this,"Data Deleted",Toast.LENGTH_LONG).show();
            else
                Toast.makeText(StudentDeleteActivity.this,"Data not Deleted",Toast.LENGTH_LONG).show();
        }

    });
    }
}
