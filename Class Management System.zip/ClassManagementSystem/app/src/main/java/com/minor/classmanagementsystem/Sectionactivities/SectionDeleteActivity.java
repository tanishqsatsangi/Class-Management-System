package com.minor.classmanagementsystem.Sectionactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.minor.classmanagementsystem.R;
import com.minor.classmanagementsystem.Studentactivities.StudentDBHelper;
import com.minor.classmanagementsystem.Studentactivities.StudentDeleteActivity;

public class SectionDeleteActivity extends AppCompatActivity {
TextView id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_section_delete);
        id=findViewById(R.id.section_delete_et);
        final SectionDBHelper sdb=new SectionDBHelper(SectionDeleteActivity.this);
        findViewById(R.id.section_delete_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer deletedRows = sdb.deletedata(id.getText().toString());
                if(deletedRows > 0)
                    Toast.makeText(SectionDeleteActivity.this,"Data Deleted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(SectionDeleteActivity.this,"Data not Deleted",Toast.LENGTH_LONG).show();
            }

        });



    }
}
