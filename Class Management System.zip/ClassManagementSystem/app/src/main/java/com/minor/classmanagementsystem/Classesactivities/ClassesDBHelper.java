package com.minor.classmanagementsystem.Classesactivities;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class ClassesDBHelper extends SQLiteOpenHelper {
    public static final String DBname = "Classes.db";
    public static final String table = "classes_table";

    String col_1 = "subject";
    String col_2 = "Section";
    String col_3 = "day";
    String col_4 = "time";

    public ClassesDBHelper(@Nullable Context context) {
        super(context, DBname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + table + "(subject TEXT PRIMARY KEY,section TEXT,day TEXT,time TEXT )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean insertdata(String subject, String section, String day, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(col_1, subject);
        cv.put(col_2, section);
        cv.put(col_3, day);
        cv.put(col_4, time);
        long result = db.insert(table, null, cv);
        if (result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from " + table, null);
        Log.i("arc",""+res);
        return res;
    }
    public boolean updatedata(String subject, String section, String day, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(col_1, subject);
        cv.put(col_2, section);
        cv.put(col_3, day);
        cv.put(col_4, time);
        Log.i("Classupdate",""+cv);
        long result = db.update(table, cv,"subject= ?",new String[]{subject});
        if (result == -1)
            return false;
        else
            return true;
    }

    public Integer deletedata (String subject) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(table, "subject= ?",new String[] {subject});
    }

}