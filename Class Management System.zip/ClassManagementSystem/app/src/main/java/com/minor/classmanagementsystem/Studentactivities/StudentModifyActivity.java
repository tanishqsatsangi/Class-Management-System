package com.minor.classmanagementsystem.Studentactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.minor.classmanagementsystem.R;

public class StudentModifyActivity extends AppCompatActivity {
    EditText id,name,section,cntact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_modify);
        id=findViewById(R.id.student_modify_studentid_et);
        name=findViewById(R.id.student_modify_name_et);
        section=findViewById(R.id.student_modify_section_et);
        cntact=findViewById(R.id.student_modify_contactno_et);
        final StudentDBHelper sdb=new StudentDBHelper(StudentModifyActivity.this);

        findViewById(R.id.student_modify_submit_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean isInserted = sdb.updatedata(id.getText().toString(),
                        name.getText().toString(),
                        section.getText().toString(),cntact.getText().toString() );

                if(isInserted == true)
                    Toast.makeText(StudentModifyActivity.this,"Data Inserted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(StudentModifyActivity.this,"Data not Inserted",Toast.LENGTH_LONG).show();

            }

        });

    }
}
