package com.minor.classmanagementsystem.Classesactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.minor.classmanagementsystem.R;
import com.minor.classmanagementsystem.Studentactivities.StudentDeleteActivity;

public class ClassesDeleteActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classes_delete);
     final EditText   id=findViewById(R.id.classes_delete_subject_et);

        findViewById(R.id.classes_delete_submit_btn).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ClassesDBHelper sdb=new ClassesDBHelper(ClassesDeleteActivity.this);
                    Integer deletedRows = sdb.deletedata(id.getText().toString());
                    if(deletedRows > 0)
                    {
                        Toast.makeText(ClassesDeleteActivity.this,"Data Deleted",Toast.LENGTH_LONG).show();

                        startActivity(new Intent(ClassesDeleteActivity.this,ClassesActivity.class));
                        finish();
                    }
                    else
                        Toast.makeText(ClassesDeleteActivity.this,"Data not Deleted",Toast.LENGTH_LONG).show();


                }
            });
    }
}
