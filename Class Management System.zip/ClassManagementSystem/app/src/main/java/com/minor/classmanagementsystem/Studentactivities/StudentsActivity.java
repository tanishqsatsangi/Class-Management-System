package com.minor.classmanagementsystem.Studentactivities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.minor.classmanagementsystem.Classesactivities.ClassesActivity;
import com.minor.classmanagementsystem.Classesactivities.ClassesAddActivity;
import com.minor.classmanagementsystem.R;

import java.util.ArrayList;

public class StudentsActivity extends AppCompatActivity {
RecyclerView recyclerView;
StudentDBHelper sdb;

ArrayList<String> id=new ArrayList<>();
ArrayList<String> name=new ArrayList<>();
ArrayList<String>section=new ArrayList<>();
ArrayList<String>contactno=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_students);
        //get student table from database
        sdb=new StudentDBHelper(StudentsActivity.this);


        Cursor res=sdb.getAllData();
        if(res.getCount()==0){
            Toast.makeText(this, "No Data Available", Toast.LENGTH_SHORT).show();
        }
        else{
            id.clear();
            name.clear();
            section.clear();
            contactno.clear();
            while(res.moveToNext()){
                id.add(res.getString(0));
                name.add(res.getString(1));
                section.add(res.getString(2));
                contactno.add(res.getString(3));
            }
        }


        recyclerView=findViewById(R.id.student_list);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(StudentsActivity.this));
        StudentAdapter adapter=new StudentAdapter(StudentsActivity.this,id,name,section,contactno);
        recyclerView.setAdapter(adapter);



        findViewById(R.id.student_add).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StudentsActivity.this, StudentAdddActivity.class));
            }
        });

        findViewById(R.id.student_modify).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StudentsActivity.this, StudentModifyActivity.class));
            }
        });
        findViewById(R.id.student_delete).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StudentsActivity.this, StudentDeleteActivity.class));
            }
        });
    }

    @Override
    protected void onResume() {

        Cursor res=sdb.getAllData();
        if(res.getCount()==0){
            Toast.makeText(this, "No Data Available", Toast.LENGTH_SHORT).show();
        }
        else{

            id.clear();
            name.clear();
            section.clear();
            contactno.clear();
            while(res.moveToNext()){
                id.add(res.getString(0));
                name.add(res.getString(1));
                section.add(res.getString(2));
                contactno.add(res.getString(3));
            }
            recyclerView.setAdapter(null);
            StudentAdapter adapter=new StudentAdapter(StudentsActivity.this,id,name,section,contactno);
            recyclerView.setAdapter(adapter);
        }

        super.onResume();
    }
}
