package com.minor.classmanagementsystem.Classesactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.minor.classmanagementsystem.R;
import com.minor.classmanagementsystem.Studentactivities.StudentAdddActivity;
import com.minor.classmanagementsystem.Studentactivities.StudentDBHelper;

public class ClassesAddActivity extends AppCompatActivity {

    EditText sub,sec,dayet,timeet;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classes_add);
    sub=findViewById(R.id.classes_add_subject_et);
    sec=findViewById(R.id.classes_add_section_et);
    dayet=findViewById(R.id.classes_add_day_et);
    timeet=findViewById(R.id.classes_add_time_et);
        final ClassesDBHelper sdb=new ClassesDBHelper(ClassesAddActivity.this);

        findViewById(R.id.classes_add_submit_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean isInserted = sdb.insertdata(sub.getText().toString(),sec.getText().toString(),dayet.getText().toString(),timeet.getText().toString());
                if(isInserted == true)
                    Toast.makeText(ClassesAddActivity.this,"Data Inserted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(ClassesAddActivity.this,"Data not Inserted",Toast.LENGTH_LONG).show();
            }

        });
    }
}
