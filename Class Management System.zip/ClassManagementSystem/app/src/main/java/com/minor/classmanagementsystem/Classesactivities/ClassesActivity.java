package com.minor.classmanagementsystem.Classesactivities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.minor.classmanagementsystem.R;
import com.minor.classmanagementsystem.Sectionactivities.SectionAddActivity;
import com.minor.classmanagementsystem.Sectionactivities.SectionsActivity;
import com.minor.classmanagementsystem.Studentactivities.StudentAdapter;
import com.minor.classmanagementsystem.Studentactivities.StudentsActivity;

import java.util.ArrayList;

public class ClassesActivity extends AppCompatActivity {
ClassesDBHelper sdb;
    RecyclerView recyclerView;


    ArrayList<String>subject=new ArrayList<>();
    ArrayList<String>section=new ArrayList<>();
    ArrayList<String>day=new ArrayList<>();
    ArrayList<String>time=new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classes);
   sdb=new ClassesDBHelper(ClassesActivity.this);

        Cursor res=sdb.getAllData();
        if(res.getCount()==0){
            Toast.makeText(this, "No Data Available", Toast.LENGTH_SHORT).show();
        }
        else{
            subject.clear();
            day.clear();
            section.clear();
            time.clear();
            while(res.moveToNext()){
                subject.add(res.getString(0));
                section.add(res.getString(1));
                day.add(res.getString(2));
                time.add(res.getString(3));
            }
        }


        recyclerView=findViewById(R.id.classes_list);
    recyclerView.setHasFixedSize(true);
    recyclerView.setLayoutManager(new LinearLayoutManager(ClassesActivity.this));
    ClassesAdapter adapter=new ClassesAdapter(ClassesActivity.this,subject,section,day,time);
    recyclerView.setAdapter(adapter);

    findViewById(R.id.classes_add).setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(ClassesActivity.this, ClassesAddActivity.class));
        }
    });
    findViewById(R.id.classes_modify).setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(ClassesActivity.this, ClassesModifyActivity.class));
        }
    });

    findViewById(R.id.classes_delete).setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(ClassesActivity.this, ClassesDeleteActivity.class));
            finish();
        }
    });

    }


    @Override
    protected void onResume() {

        Cursor res=sdb.getAllData();
        if(res.getCount()==0){
            Toast.makeText(this, "No Data Available", Toast.LENGTH_SHORT).show();
        }
        else{
            subject.clear();
            section.clear();
            day.clear();
            time.clear();
            while(res.moveToNext()){
                subject.add(res.getString(0));
                section.add(res.getString(1));
                day.add(res.getString(2));
                time.add(res.getString(3));
            }
            recyclerView.setAdapter(null);
            ClassesAdapter adapter=new ClassesAdapter(ClassesActivity.this,subject,section,day,time);
            recyclerView.setAdapter(adapter);
        }

        super.onResume();
    }


}
