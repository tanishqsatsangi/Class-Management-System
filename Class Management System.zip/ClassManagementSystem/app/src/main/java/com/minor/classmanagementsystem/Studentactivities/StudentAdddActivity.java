package com.minor.classmanagementsystem.Studentactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.minor.classmanagementsystem.R;
import com.minor.classmanagementsystem.mainactivites.MainActivity;

public class StudentAdddActivity extends AppCompatActivity {
EditText id,name,section,cntact;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_addd);
        id=findViewById(R.id.student_add_studentid_et);
        name=findViewById(R.id.student_add_name_et);
        section=findViewById(R.id.student_add_section_et);
        cntact=findViewById(R.id.student_add_contactno_et);
        final StudentDBHelper sdb=new StudentDBHelper(StudentAdddActivity.this);

        findViewById(R.id.student_add_submit_btn).setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View v) {

           boolean isInserted = sdb.insertdata(id.getText().toString(),
                   name.getText().toString(),
                   section.getText().toString(),cntact.getText().toString() );
           if(isInserted == true)
               Toast.makeText(StudentAdddActivity.this,"Data Inserted",Toast.LENGTH_LONG).show();
           else
               Toast.makeText(StudentAdddActivity.this,"Data not Inserted",Toast.LENGTH_LONG).show();
       }

   });
    }
}
