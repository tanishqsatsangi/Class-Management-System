package com.minor.classmanagementsystem.Sectionactivities;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.minor.classmanagementsystem.R;

import java.util.ArrayList;

public class SectionAdapter extends  RecyclerView.Adapter<SectionAdapter.SectionHolder>{

    ArrayList<String> mid;
    public  SectionAdapter(){

    }
    public SectionAdapter(Context context,ArrayList<String> id){
        mid=id;

    }

    @NonNull
    @Override
    public SectionHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.text_section_layout,parent,false);
        return new SectionHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull SectionHolder holder, int position) {
        holder.id.setText(mid.get(position));

    }

    @Override
    public int getItemCount() {
        return mid.size();
    }

    public  class SectionHolder extends RecyclerView.ViewHolder{

        TextView id;
        public SectionHolder(@NonNull View itemView) {
            super(itemView);
            id= itemView.findViewById(R.id.section_text1);
        }

    }
}
