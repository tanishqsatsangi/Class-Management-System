package com.minor.classmanagementsystem.Classesactivities;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.minor.classmanagementsystem.R;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class ClassesAdapter  extends RecyclerView.Adapter<ClassesAdapter.ViewHolder> {

    ArrayList <String> msubject,msection,mday,mtime;
        Context mcontext;
    public  ClassesAdapter(){

    }
    public ClassesAdapter(Context context, ArrayList<String> subject, ArrayList<String > section, ArrayList<String>day, ArrayList<String>time){
        msubject=subject;
        mcontext=context;
        msection=section;
        mday=day;
        mtime=time;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.text_classes_layout,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.section.setText(msection.get(position));
        holder.subject.setText(msubject.get(position));
        holder.day.setText(mday.get(position));
        holder.time.setText(mtime.get(position));

    }

    @Override
    public int getItemCount() {
        return msubject.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView subject,section,day,time;
        LinearLayout parentLayout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            subject=itemView.findViewById(R.id.classes_text1);
            section=itemView.findViewById(R.id.classes_text2);
            day=itemView.findViewById(R.id.classes_text3);
            time=itemView.findViewById(R.id.classes_text4);
            parentLayout=itemView.findViewById(R.id.classes_layout_parent);
        }



    }
}
