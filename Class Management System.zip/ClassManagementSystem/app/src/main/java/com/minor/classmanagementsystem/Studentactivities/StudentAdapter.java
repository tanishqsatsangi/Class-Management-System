package com.minor.classmanagementsystem.Studentactivities;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.minor.classmanagementsystem.R;

import java.util.ArrayList;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.StudentHolder> {
    Context mcontext;
    ArrayList <String> mid,mname,msection,mcontactno;
    public StudentAdapter(){
    //empty required constructor
    }
    public  StudentAdapter(Context context,ArrayList<String> id,ArrayList<String > name,ArrayList<String>section,ArrayList<String>contact){
    mcontactno=contact;
    mcontext=context;
    mid=id;
    mname=name;
    msection=section;
    }
    @NonNull
    @Override
    public StudentHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.text_student_layout,parent,false);
        return new StudentHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull StudentHolder holder, int position) {
        holder.id.setText(mid.get(position));
        holder.name.setText(mname.get(position));
        holder.section.setText(msection.get(position));
        holder.contact.setText(mcontactno.get(position));
        Log.i("arr",""+mid);
        
    }

    @Override
    public int getItemCount() {
        return mid.size();
    }

    public class StudentHolder extends  RecyclerView.ViewHolder{
TextView id,name,section,contact;
        public StudentHolder(@NonNull View itemView) {
            super(itemView);
            id= itemView.findViewById(R.id.text1);
            name=itemView.findViewById(R.id.text2);
            section=itemView.findViewById(R.id.text3);
            contact=itemView.findViewById(R.id.text4);



        }
    }
}
