package com.minor.classmanagementsystem.mainactivites;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.minor.classmanagementsystem.R;

public class CheckPasswordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_password);
        final SharedPreferences pref = getApplicationContext().getSharedPreferences("Password", 0); // 0 - for private mode
        final EditText pswdet=findViewById(R.id.checkpswd_et);

        findViewById(R.id.checkpswd_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    String pass=pswdet.getText().toString().trim();
                    if(pass.isEmpty() || !pass.equals(pref.getString("Password",""))){
                        Toast.makeText(CheckPasswordActivity.this, "Invalid Password", Toast.LENGTH_SHORT).show();
                    }
                    if(pass.equals(pref.getString("Password",""))){
                        Toast.makeText(CheckPasswordActivity.this, "Log in Succesful Redricting!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(CheckPasswordActivity.this,CategoryActivity.class));
                    }
            }
        });
    }
}
