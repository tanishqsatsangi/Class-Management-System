package com.minor.classmanagementsystem.Sectionactivities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.minor.classmanagementsystem.R;
import com.minor.classmanagementsystem.Studentactivities.StudentAdapter;
import com.minor.classmanagementsystem.Studentactivities.StudentsActivity;

import java.util.ArrayList;

public class SectionsActivity extends AppCompatActivity {
RecyclerView recyclerView;

    ArrayList<String> id=new ArrayList<>();
    SectionDBHelper sdb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sections);

      sdb=new SectionDBHelper(SectionsActivity.this);

        Cursor res=sdb.getAllData();
        if(res.getCount()==0){
            Toast.makeText(this, "No Data Available", Toast.LENGTH_SHORT).show();
        }
        else{
            id.clear();
            while(res.moveToNext()){
                id.add(res.getString(0));
            }
        }


        recyclerView=findViewById(R.id.sectionrecyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(SectionsActivity.this));
        SectionAdapter adapter=new SectionAdapter(SectionsActivity.this,id);
        recyclerView.setAdapter(adapter);

    findViewById(R.id.section_add).setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(SectionsActivity.this,SectionAddActivity.class));
        }
    });

    findViewById(R.id.section_modify).setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(SectionsActivity.this,SectionModifyActivity.class));
        }
    });
    findViewById(R.id.section_delete).setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(SectionsActivity.this,SectionDeleteActivity.class));
        }
    });
    }

    @Override
    protected void onResume() {

        Cursor res=sdb.getAllData();
        if(res.getCount()==0){
            Toast.makeText(this, "No Data Available", Toast.LENGTH_SHORT).show();
        }
        else{

            id.clear();
            while(res.moveToNext()){
                id.add(res.getString(0));
            }
            recyclerView.setAdapter(null);
           SectionAdapter adapter=new SectionAdapter(SectionsActivity.this,id);
            recyclerView.setAdapter(adapter);
        }

        super.onResume();
    }
}
