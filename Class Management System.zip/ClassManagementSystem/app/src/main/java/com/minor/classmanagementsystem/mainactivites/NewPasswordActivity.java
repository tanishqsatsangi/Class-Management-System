package com.minor.classmanagementsystem.mainactivites;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.minor.classmanagementsystem.R;

public class NewPasswordActivity extends AppCompatActivity {

    EditText pswd,cnfpswd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_password);
        final SharedPreferences pref = getApplicationContext().getSharedPreferences("Password", 0); // 0 - for private mode
        final SharedPreferences.Editor editor = pref.edit();
        pswd=findViewById(R.id.newpswd_et);
        cnfpswd=findViewById(R.id.cnfpswd_et);
        findViewById(R.id.submit_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(pref.getString("Password","").isEmpty()){
                    if(cnfpswd.getText().toString().isEmpty() || pswd.getText().toString().isEmpty()){
                        Toast.makeText(NewPasswordActivity.this, "PLease enter Password and Confirm PAssword", Toast.LENGTH_SHORT).show();
                    }
                    else if(!pswd.getText().toString().equals(cnfpswd.getText().toString())){
                        Toast.makeText(NewPasswordActivity.this, "Password Mismatch", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        editor.putString("Password",pswd.getText().toString());
                        editor.commit();
                        Toast.makeText(NewPasswordActivity.this, "Password Created Redirecting", Toast.LENGTH_SHORT).show();

                        startActivity(new Intent(NewPasswordActivity.this,CheckPasswordActivity.class));
                    }

                }//if pref ends

            else {
                    Toast.makeText(NewPasswordActivity.this, "Password exists use it to log in", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(NewPasswordActivity.this,CheckPasswordActivity.class));

                }
            }

        });
    }
}
