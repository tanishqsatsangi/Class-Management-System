package com.minor.classmanagementsystem.Sectionactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.minor.classmanagementsystem.R;
import com.minor.classmanagementsystem.Studentactivities.StudentAdddActivity;
import com.minor.classmanagementsystem.Studentactivities.StudentDBHelper;

public class SectionAddActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_section_add);
        final SectionDBHelper sdb=new SectionDBHelper(SectionAddActivity.this);

        findViewById(R.id.section_add_btn).setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String text="";
                    EditText et =findViewById(R.id.section_add_et);
                    text=et.getText().toString();
            boolean isInserted = sdb.insertdata(text);
            if(isInserted == true)
                Toast.makeText(SectionAddActivity.this,"Data Inserted",Toast.LENGTH_LONG).show();
            else
                Toast.makeText(SectionAddActivity.this,"Data not Inserted",Toast.LENGTH_LONG).show();
        }
    });
    }
}
