package com.minor.classmanagementsystem.Classesactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.minor.classmanagementsystem.R;

public class ClassesModifyActivity extends AppCompatActivity {
    EditText sub,sec,dayet,timeet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classes_modify);
        sub=findViewById(R.id.classes_modify_subject_et);
        sec=findViewById(R.id.classes_modify_section_et);
        dayet=findViewById(R.id.classes_modify_day_et);
        timeet=findViewById(R.id.classes_modify_time_et);

        final ClassesDBHelper sdb=new ClassesDBHelper(ClassesModifyActivity.this);

        findViewById(R.id.classes_modify_submit_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean isInserted = sdb.updatedata(sub.getText().toString(),sec.getText().toString(),dayet.getText().toString(),timeet.getText().toString());
                if(isInserted == true)
                    Toast.makeText(ClassesModifyActivity.this,"Data Inserted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(ClassesModifyActivity.this,"Data not Inserted",Toast.LENGTH_LONG).show();
            }
        });
    }
}
