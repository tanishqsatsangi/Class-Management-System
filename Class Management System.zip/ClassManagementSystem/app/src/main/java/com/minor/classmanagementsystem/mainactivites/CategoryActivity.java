package com.minor.classmanagementsystem.mainactivites;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.minor.classmanagementsystem.Classesactivities.ClassesActivity;
import com.minor.classmanagementsystem.R;
import com.minor.classmanagementsystem.Sectionactivities.SectionsActivity;
import com.minor.classmanagementsystem.Studentactivities.StudentsActivity;

public class CategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        findViewById(R.id.btn_Classes).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CategoryActivity.this, ClassesActivity.class));
            }
        });
        findViewById(R.id.btn_section).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CategoryActivity.this, SectionsActivity.class));
            }
        });
        findViewById(R.id.btn_category_Student).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CategoryActivity.this, StudentsActivity.class));
            }
        });

        findViewById(R.id.btnSettings).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CategoryActivity.this,SettingsActivity.class));
            }
        });
        findViewById(R.id.btn_exit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
                //closes current and all activity before it
            }
        });
    }
}
