package com.minor.classmanagementsystem.Sectionactivities;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class SectionDBHelper extends SQLiteOpenHelper {
    public static final String DBname = "Section.db";
    public static final String table = "section_table";

    String col_1 = "Sectionid";
    public SectionDBHelper(@Nullable Context context) {
        super(context, DBname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + table + "(Sectionid TEXT PRIMARY KEY )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean insertdata(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(col_1, id);
        long result = db.insert(table, null, cv);
        if (result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from " + table, null);
        Log.i("arc",""+res);
        return res;
    }
    public boolean updatedata(String id,String newsec) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(col_1, newsec);
        long result = db.update(table, cv,"Sectionid= ?",new String[]{id});

        if (result == -1)
            return false;
        else
            return true;
    }

    public Integer deletedata (String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(table, "Sectionid= ?",new String[] {id});
    }

}