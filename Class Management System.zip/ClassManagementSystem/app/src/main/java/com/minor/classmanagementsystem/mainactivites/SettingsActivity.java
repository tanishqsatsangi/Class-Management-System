package com.minor.classmanagementsystem.mainactivites;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.minor.classmanagementsystem.R;

public class SettingsActivity extends AppCompatActivity {
        EditText oldpswd,newpswd,cnfpswd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        final SharedPreferences pref = getApplicationContext().getSharedPreferences("Password", 0); // 0 - for private mode
        final SharedPreferences.Editor editor = pref.edit();
        oldpswd=findViewById(R.id.setting_oldpswd);
        newpswd=findViewById(R.id.setting_newpswd);
        cnfpswd=findViewById(R.id.setting_cnnfrmpswd);
        findViewById(R.id.setting_change_pswd).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String old=oldpswd.getText().toString();
                String newps=newpswd.getText().toString();
                String cmfps=cnfpswd.getText().toString();
                if(old.isEmpty() || newps.isEmpty() || cmfps.isEmpty()){
                    Toast.makeText(SettingsActivity.this, "Please fill all field", Toast.LENGTH_SHORT).show();
                }
                if(old.equals(pref.getString("Password","")) && (newps.equals(cmfps)) ){
                    editor.putString("Password",newps);
                    editor.commit();
                    Toast.makeText(SettingsActivity.this, "Password Created Redirecting", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(SettingsActivity.this,CheckPasswordActivity.class));
                }
            }
        });


    }
}
