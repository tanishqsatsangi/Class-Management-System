package com.minor.classmanagementsystem.Studentactivities;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class StudentDBHelper extends SQLiteOpenHelper {
 public static final String DBname = "Student.db";
 public static final String table = "student_table";

 String col_1 = "Studentid";
 String col_2 = "name";
 String col_3 = "section";
 String col_4 = "contactno";

 public StudentDBHelper(@Nullable Context context) {
  super(context, DBname, null, 1);
 }

 @Override
 public void onCreate(SQLiteDatabase db) {
  db.execSQL("create table " + table + "(studentid TEXT PRIMARY KEY,name TEXT,section TEXT,contactno TEXT )");
 }

 @Override
 public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

 }

 public boolean insertdata(String id, String name, String section, String contactno) {
  SQLiteDatabase db = this.getWritableDatabase();
  ContentValues cv = new ContentValues();
  cv.put(col_1, id);
  cv.put(col_2, name);
  cv.put(col_3, section);
  cv.put(col_4, contactno);
  long result = db.insert(table, null, cv);
  if (result == -1)
   return false;
  else
   return true;
 }

 public Cursor getAllData() {
  SQLiteDatabase db = this.getWritableDatabase();
  Cursor res = db.rawQuery("select * from " + table, null);
  Log.i("arc",""+res);
  return res;
 }
 public boolean updatedata(String id, String name, String section, String contactno) {
  SQLiteDatabase db = this.getWritableDatabase();
  ContentValues cv = new ContentValues();
  cv.put(col_1, id);
  cv.put(col_2, name);
  cv.put(col_3, section);
  cv.put(col_4, contactno);
  long result = db.update(table, cv,"studentid= ?",new String[]{id});

  if (result == -1)
   return false;
  else
   return true;
 }

 public Integer deletedata (String id) {
  SQLiteDatabase db = this.getWritableDatabase();
  return db.delete(table, "studentid= ?",new String[] {id});
 }

}