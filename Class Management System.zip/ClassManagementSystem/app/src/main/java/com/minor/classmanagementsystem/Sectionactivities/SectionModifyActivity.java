package com.minor.classmanagementsystem.Sectionactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.minor.classmanagementsystem.R;
import com.minor.classmanagementsystem.Studentactivities.StudentDBHelper;
import com.minor.classmanagementsystem.Studentactivities.StudentModifyActivity;

public class SectionModifyActivity extends AppCompatActivity {
    TextView id,newsection;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_section_modify);
        id=findViewById(R.id.section_modify_et);
        newsection=findViewById(R.id.section_modify_new_et);


        final SectionDBHelper sdb=new SectionDBHelper(SectionModifyActivity.this);

        findViewById(R.id.section_modify_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text="",newtext="";
                text=id.getText().toString();
                newtext=newsection.getText().toString();
                boolean isInserted = sdb.updatedata(text,newtext);

                if(isInserted == true)
                    Toast.makeText(SectionModifyActivity.this,"Data Inserted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(SectionModifyActivity.this,"Data not Inserted",Toast.LENGTH_LONG).show();

            }

        });

    }
}
